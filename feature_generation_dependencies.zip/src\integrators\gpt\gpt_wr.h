/*
    This file is part of Mitsuba, a physically based rendering system.

    Copyright (c) 2007-2014 by Wenzel Jakob and others.

    Mitsuba is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License Version 3
    as published by the Free Software Foundation.

    Mitsuba is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#if !defined(__GPT_WR_H)
#define __GPT_WR_H

#include <mitsuba/render/imageblock.h>
#include <mitsuba/core/fresolver.h>

// [FG] Header for feature generation
#include <vector>
#include "FeatureGenerationOptions.h"

MTS_NAMESPACE_BEGIN

/* ==================================================================== */
/*                             Work result                              */
/* ==================================================================== */

/**
   Gradient-Domain path tracing needs its own WorkResult implementation,
   since it needs to accumulate sampled data into multiple buffers simultaneously.
*/
class GPTWorkResult : public WorkResult {
public:
	// [FG] In feature generation, our final output is new feature.
	const size_t BUFFER_COUNT = 1;
	//const size_t BUFFER_COUNT = 5;

	GPTWorkResult(const ReconstructionFilter *filter,
			Vector2i blockSize = Vector2i(-1, -1), int extraBorder = 0);

	// Clear the contents of the work result
	void clear();

	/// Fill the work result with content acquired from a binary data stream
	virtual void load(Stream *stream);

	/// Serialize a work result to a binary data stream
	virtual void save(Stream *stream) const;

	/// Accumulate another work result into this one
	void put(const GPTWorkResult *workResult);

	/// Add a sample to a buffer.
	inline void put(const Point2 &sample, const Spectrum &spec, float alpha, float weight, int buffer) {
		Float temp[SPECTRUM_SAMPLES + 2];
		for (int i=0; i<SPECTRUM_SAMPLES; ++i)
			temp[i] = spec[i];
		temp[SPECTRUM_SAMPLES] = 1.0f;
		temp[SPECTRUM_SAMPLES + 1] = weight;

		m_block[buffer]->put(sample, temp);
	}


	/* ----------------------------------------------------------------------------------- */
	//                               Feature generation									   //
	/* ----------------------------------------------------------------------------------- */
	inline void updateMean(std::vector<Vector4>& _buf, const Point2 &sample, const Spectrum &spec, Float w) {
		const Point2i offset = m_block[0]->getOffset();
		const int borderSize = m_block[0]->getBorderSize();
		Bitmap* bitmap = m_block[0]->getBitmap();
		const Vector2i size = bitmap->getSize();

		/* Convert to pixel coordinates within the image block */
		const Point2 pos(
			sample.x - 0.5f - (offset.x - borderSize),
			sample.y - 0.5f - (offset.y - borderSize));

		const Float filterRadius = m_block[0]->getFilterRadius();

		const Point2i min(std::max((int)std::ceil(pos.x - filterRadius), 0),
			std::max((int)std::ceil(pos.y - filterRadius), 0)),
			max(std::min((int)std::floor(pos.x + filterRadius), size.x - 1),
				std::min((int)std::floor(pos.y + filterRadius), size.y - 1));

		/* Rasterize the filtered sample into the framebuffer */
		Float r, g, b;
		for (int y = min.y, yr = 0; y <= max.y; ++y, ++yr) {
			for (int x = min.x, xr = 0; x <= max.x; ++x, ++xr) {
				int i = y * (size_t)size.x + x;
				spec.toLinearRGB(r, g, b);
				_buf[i] += Vector4(r, g, b, w);
			}
		}
	}

	inline void updateMeanAndVariance(std::vector<Vector4>& _buf, std::vector<BAGG_VAR>& _var, const Point2 &sample, const Spectrum &spec, Float w) {
		const Point2i offset = m_block[0]->getOffset();
		const int borderSize = m_block[0]->getBorderSize();
		Bitmap* bitmap = m_block[0]->getBitmap();
		const Vector2i size = bitmap->getSize();

		/* Convert to pixel coordinates within the image block */
		const Point2 pos(
			sample.x - 0.5f - (offset.x - borderSize),
			sample.y - 0.5f - (offset.y - borderSize));
			
		const Float filterRadius = m_block[0]->getFilterRadius();		

		const Point2i min(std::max((int)std::ceil(pos.x - filterRadius), 0),
			std::max((int)std::ceil(pos.y - filterRadius), 0)),
			max(std::min((int)std::floor(pos.x + filterRadius), size.x - 1),
			std::min((int)std::floor(pos.y + filterRadius), size.y - 1));

		/* Rasterize the filtered sample into the framebuffer */
		Float r, g, b;
		for (int y = min.y, yr = 0; y <= max.y; ++y, ++yr) {
			for (int x = min.x, xr = 0; x <= max.x; ++x, ++xr) {				
				int i = y * (size_t)size.x + x;			
				spec.toLinearRGB(r, g, b);

				// Note: This is somehow different from the typical weighting scheme
				// We follow the original gpt based weighting: check out the block-put() function
				_buf[i] += Vector4(r, g, b, w);
				_var[i].add(r, g, b, w);
				++m_nSample[i];
			}
		}
	}

	// Assume an uniform weights for gradient samples
	// Add a sample to a buffer
	inline void putSamples(std::vector<BAGG_PIXEL>& _gradSamples, const Point2 &sample, const Spectrum &spec, const int spp, const Float w) {
		const Point2i offset = m_block[0]->getOffset();
		const int borderSize = m_block[0]->getBorderSize();
		Bitmap* bitmap = m_block[0]->getBitmap();
		const Vector2i size = bitmap->getSize();

		/* Convert to pixel coordinates within the image block */
		const Point2 pos(
			sample.x - 0.5f - (offset.x - borderSize),
			sample.y - 0.5f - (offset.y - borderSize));

		const float filterRadius = m_block[0]->getFilterRadius();

		const Point2i min(std::max((int)std::ceil(pos.x - filterRadius), 0),
			std::max((int)std::ceil(pos.y - filterRadius), 0)),
			max(std::min((int)std::floor(pos.x + filterRadius), size.x - 1),
				std::min((int)std::floor(pos.y + filterRadius), size.y - 1));

		/* Rasterize the filtered sample into the framebuffer */
		for (int y = min.y, yr = 0; y <= max.y; ++y, ++yr) {
			for (int x = min.x, xr = 0; x <= max.x; ++x, ++xr) {
				Float r, g, b;
				spec.toLinearRGB(r, g, b);
				_gradSamples[y * (size_t)size.x + x].add(r, g, b, w, spp);
			}
		}
	}
	/* ----------------------------------------------------------------------------------- */


	inline const ImageBlock *getImageBlock(int buffer = 0) const {
		return m_block[buffer].get();
	}

	inline void setSize(const Vector2i &size) {
		for (size_t i = 0; i < m_block.size(); ++i)
			m_block[i]->setSize(size);

		// [FG] Initialize several buffers for feature generation
		Bitmap* bitmap = m_block[0]->getBitmap();
		const Vector2i sizeBitmap = bitmap->getSize();	
		int nEle = sizeBitmap.x * sizeBitmap.y;

		if (nEle != m_img.size()) {
			m_img.resize(nEle);
			m_veryDirectImg.resize(nEle);
			m_nSample.resize(nEle);
			m_dxSamples.resize(nEle);
			m_dySamples.resize(nEle);
			m_varImg.resize(nEle);
			m_initSamples.resize(nEle);
		}
		std::fill(m_img.begin(), m_img.end(), Vector4(0.0));
		std::fill(m_veryDirectImg.begin(), m_veryDirectImg.end(), Vector4(0.0));
		std::fill(m_nSample.begin(), m_nSample.end(), 0);
		for (int i = 0; i < nEle; ++i) {
			m_dxSamples[i].init();
			m_dySamples[i].init();
			m_initSamples[i].init();
			m_varImg[i].init();
		}
		// -------------------------------------------------------
	}

	inline const Point2i &getOffset() const {
		return m_block[0]->getOffset();
	}

	inline void setOffset(const Point2i &offset) {
		for (size_t i = 0; i < m_block.size(); ++i)
			m_block[i]->setOffset(offset);
	}

	/// Return a string representation
	std::string toString() const;

	MTS_DECLARE_CLASS()

protected:
	/// Virtual destructor
	virtual ~GPTWorkResult();

protected:
	ref_vector<ImageBlock> m_block;

public:
	/* ---------------------------------------------------------------- */
	// Feature Generation
	/* ---------------------------------------------------------------- */
	std::vector<BAGG_PIXEL> m_dxSamples, m_dySamples, m_initSamples;
	std::vector<Vector4> m_img, m_veryDirectImg;
	std::vector<int> m_nSample;

	// to support for variance of weighted mean
	std::vector<BAGG_VAR> m_varImg;
	/* ---------------------------------------------------------------- */
};

MTS_NAMESPACE_END

#endif /* __GBDPT_WR_H */