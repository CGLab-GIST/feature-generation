/*
    This file is part of Mitsuba, a physically based rendering system.

    Copyright (c) 2007-2014 by Wenzel Jakob and others.

    Mitsuba is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License Version 3
    as published by the Free Software Foundation.

    Mitsuba is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#if !defined(__GPT_H)
#define __GPT_H

#include <mitsuba/mitsuba.h>
#include "gpt_wr.h"

// [FG] Header for feature generation
#include <vector_types.h>
#include "FeatureGenerationOptions.h"
#include "FeatureGeneration.h"

MTS_NAMESPACE_BEGIN


/* ==================================================================== */
/*                         Configuration storage                        */
/* ==================================================================== */


/// Configuration for the gradient path tracer.
struct GradientPathTracerConfig {
    int m_maxDepth;
	int m_minDepth;
    int m_rrDepth;
	bool m_strictNormals;
	Float m_shiftThreshold;
	bool m_reconstructL1;
	bool m_reconstructL2;
	Float m_reconstructAlpha;

	// [FG] Configuration for feature generation
	bool m_reconstructFeature;
};



/* ==================================================================== */
/*                         Integrator                         */
/* ==================================================================== */


 
class GradientPathIntegrator : public MonteCarloIntegrator {
public:
	GradientPathIntegrator(const Properties &props);

	/// Unserialize from a binary data stream
	GradientPathIntegrator(Stream *stream, InstanceManager *manager);


	/// Starts the rendering process.
	bool render(Scene *scene,
		RenderQueue *queue, const RenderJob *job,
		int sceneResID, int sensorResID, int samplerResID);


	/// Renders a block in the image.
	void renderBlock(const Scene *scene, const Sensor *sensor, Sampler *sampler, GPTWorkResult *block,
		const bool &stop, const std::vector< TPoint2<uint8_t> > &points) const;

	void serialize(Stream *stream, InstanceManager *manager) const;
	std::string toString() const;


	/// Used by Mitsuba for initializing sub-surface scattering.
	Spectrum Li(const RayDifferential &ray, RadianceQueryRecord &rRec) const;

	// [FG] functions for generating our feature
	void setBitmapFromFloat4(Float *dest, const float4* src, int nPix);
	void calcMeanAndVariance(std::vector<float4>& _directImg, std::vector<float4>& _img, std::vector<float4>& _varImg,							 
							 const std::vector<Vector4>& _bufDirectImg, const std::vector<Vector4>& _bufImg, std::vector<BAGG_VAR>& _bufVarImg);
	void generateNewFeature(ref<Film>& film, bool isFinal);

	MTS_DECLARE_CLASS()

protected:

	
private:
	GradientPathTracerConfig m_config; 

	// [FG] Feature generator class
	FeatureGenerator tester;
};


MTS_NAMESPACE_END

#endif /* __GBDPT_H */
